package com.prac;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

import com.prac.board.mapper.BoardMapper;

@Controller
public class JspTest {
	@Resource(name="com.prac.board.mapper.BoardMapper")
	BoardMapper mBoardMapper;
	
	@RequestMapping("/test")
	private String jspTest() throws Exception{
		System.out.println(mBoardMapper.boardCount());
		return "test";
	}
}
