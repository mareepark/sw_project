package com.prac.board.controller;

import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prac.board.domain.CultureVO;
import com.prac.board.domain.FacilityVO;
import com.prac.board.domain.FestivalVO;
import com.prac.board.domain.OasisVO;
import com.prac.board.domain.TreasureVO;
import com.prac.board.parse.APIParse;
import com.prac.board.service.APIService;


@Controller
public class APIController {
	@Resource(name = "com.prac.board.service.APIService")
	APIService mAPIService;
	
	
	@RequestMapping(value="/oasis/parse")
    private String oasisInsertProc(HttpServletRequest request) throws Exception {
		OasisVO oasis = null;
		APIParse Aparse = new APIParse();
		int id;
		
		ArrayList<OasisVO> samp = Aparse.OaAPIParser();
		
		int idx = 0;
		while(true) {
			oasis = new OasisVO();
			oasis = samp.get(idx);
			
			id = oasis.getOasisid();

			if(mAPIService.oasisFindService(id) == 1) {
				idx++;
			}else {
				mAPIService.oasisInsertService(oasis);
				idx++;
			}
			
			if(id == 0) {
				System.out.println("Parsing End");
				break;
			}
		}
		return "redirect:/oasis/list";
	}
	
	
	@RequestMapping(value="/treasure/parse")
    private String treasureInsertProc(HttpServletRequest request) throws Exception {
		TreasureVO treasure = null;
		APIParse Aparse = new APIParse();
		int id;
		
		ArrayList<TreasureVO> samp = Aparse.TrAPIParser();
		
		int idx = 0;
		while(true) {
			treasure = new TreasureVO();
			treasure = samp.get(idx);
			
			id = treasure.getIdx();
			
			if(mAPIService.treasureFindService(id) == 1) {
				idx++;
			}else {
				mAPIService.treasureInsertService(treasure);
				idx++;
			}
			
			if(id == 0) {
				System.out.println("Parsing End");
				break;
			}
		}
		return "redirect:/treasure/list";
	}
	
	
	@RequestMapping(value="/festival/parse")
    private String festivalInsertProc(HttpServletRequest request) throws Exception {
		FestivalVO festival = null;
		APIParse Aparse = new APIParse();
		int id;
		
		ArrayList<FestivalVO> samp = Aparse.FsAPIParser();
		
		int idx = 0;
		while(true) {
			festival = new FestivalVO();
			festival = samp.get(idx);
			
			id = festival.getIdx();
			
			if(mAPIService.festivalFindService(id) == 1) {
				idx++;
			}else {
				mAPIService.festivalInsertService(festival);
				idx++;
			}
			
			if(id == 0) {
				System.out.println("Parsing End");
				break;
			}
		}
		return "redirect:/festival/list";
	}
	
	@RequestMapping(value="/facility/parse")
    private String facilityInsertProc(HttpServletRequest request) throws Exception {
		FacilityVO facility = null;
		APIParse Aparse = new APIParse();
		int id;
		
		ArrayList<FacilityVO> samp = Aparse.FaAPIParser();
		
		int idx = 0;
		while(true) {
			facility = new FacilityVO();
			facility = samp.get(idx);
			
			id = facility.getIdx();
			
			if(mAPIService.facilityFindService(id) == 1) {
				idx++;
			}else {
				mAPIService.facilityInsertService(facility);
				idx++;
			}
			
			if(id == 0) {
				System.out.println("Parsing End");
				break;
			}
		}
		return "redirect:/facility/list";
	}
	
	@RequestMapping(value="/culture/parse")
    private String cultureInsertProc(HttpServletRequest request) throws Exception {
		CultureVO culture = null;
		APIParse Aparse = new APIParse();
		int id;
		
		ArrayList<ArrayList<CultureVO>> ssamp = Aparse.CuAPIParser();
		ArrayList<CultureVO> samp = null;
		
		for(int ix = 0 ; ix < ssamp.size() ; ix++) {
			int idx = 0;
			while(true) {
				samp = ssamp.get(ix);
				
				culture = new CultureVO();
				culture = samp.get(idx);
			
				id = culture.getIdx();
				
				if(mAPIService.cultureFindService(id) == 1) {
					idx++;
				}else {
					if(culture.getIdx() == 2194)
						culture.setDescription("제94회 전국체육대회 문화행사 현황\n" + 
								"○ 총 99개 행사 : 공연 45개, 체험행사 23개, 전시 16개, 기타 15개");
					else if(culture.getIdx() == 160)
						culture.setDescription("제1회 함세덕 희곡상당선작");
					mAPIService.cultureInsertService(culture);
					idx++;
				}
			
				if(id == 0) {
					System.out.println("Parsing End");
					break;
				}
			}
		}
		return "redirect:/culture/list";
	}
	
	@RequestMapping(value="/oasis/del")
    private String oasisDeletetProc(HttpServletRequest request) throws Exception {
		mAPIService.oasisDeleteService();
		return "redirect:/oasis/parse";
	}
	
	@RequestMapping("/treasure/del")
    private String treasureDeletetProc(HttpServletRequest request) throws Exception {
		mAPIService.treasureDeleteService();
		return "redirect:/treasure/parse";
	}
	
	@RequestMapping("/festival/del")
    private String festivalDeletetProc(HttpServletRequest request) throws Exception {
		mAPIService.festivalDeleteService();
		return "redirect:/festival/parse";
	}
	
	@RequestMapping("/facility/del")
    private String facilityDeletetProc(HttpServletRequest request) throws Exception {
		mAPIService.facilityDeleteService();
		return "redirect:/facility/parse";
	}
	
	@RequestMapping("/culture/del")
    private String cultureDeletetProc(HttpServletRequest request) throws Exception {
		mAPIService.cultureDeleteService();
		return "redirect:/culture/parse";
	}
}