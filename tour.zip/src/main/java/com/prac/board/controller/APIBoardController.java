package com.prac.board.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.prac.board.domain.ParameterVO;
import com.prac.board.parse.Criteria;
import com.prac.board.parse.PageMarker;
import com.prac.board.service.APIBoardService;

@Controller
public class APIBoardController {
	@Resource(name = "com.prac.board.service.APIBoardService")
	APIBoardService mAPIBoardService;


		//oasisADD 서구 / region 중구 / address 인천광역시 연수구 청학동 496-4 광장프라자
		//period 매년 x월중, 상설/비상설, 정월대보름 / place_gugun 중구 + sdate edate 20181024 20181025
		//MainService 별로 필요한 parameter 전달 innerHTML에서 위치 불러오고
		//시간은 java Date 함수 이용해서 format 사용
	@RequestMapping(value= "/")
	public ModelAndView mainPage() throws Exception{
		ModelAndView mav = new ModelAndView("/index");
		
		List<Map<String, Object>> oasis = mAPIBoardService.oasisMainService();
		List<Map<String, Object>> treasure = mAPIBoardService.treasureMainService();
		List<Map<String, Object>> facility = mAPIBoardService.facilityMainService();
		List<Map<String, Object>> festival = mAPIBoardService.festivalMainService();
		List<Map<String, Object>> culture = mAPIBoardService.cultureMainService();
		
		mav.addObject("oasis", oasis);
		mav.addObject("treasure", treasure);
		mav.addObject("facility", facility);
		mav.addObject("festival", festival);
		mav.addObject("culture", culture);
		
		return mav;
	}
	

	@RequestMapping(value="/index")
	public ModelAndView mainPage(@RequestParam(value="location", defaultValue="default") String location) throws Exception{
		ModelAndView mav = new ModelAndView("/index");
		
		Calendar cal = Calendar.getInstance();
		String locat = location.toString();
		
		String fulltime = cal.get(Calendar.YEAR) + "" + (cal.get(Calendar.MONTH) + 1) + "" + cal.get(Calendar.DAY_OF_MONTH);
		String[] str = locat.split("\\s");
		
		int full = Integer.parseInt(fulltime);
		int month = cal.get(Calendar.MONTH) + 1;

		if(!str[0].equals("인천광역시")) {
			locat = "인천광역시 서구";
			str = locat.split("\\s");
		}

		ParameterVO para = new ParameterVO();
		para.setTime(full);
		para.setLocation(str[1].toString());
		
		List<Map<String, Object>> oasis = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> treasure = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> facility = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> festival = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> culture = new ArrayList<Map<String,Object>>();
		
		if(!location.equals("default")) {
			oasis = mAPIBoardService.oasisSubService(str[1].toString());
			treasure = mAPIBoardService.treasureSubService(str[1].toString());
			facility = mAPIBoardService.facilitySubService(str[1].toString());
			festival = mAPIBoardService.festivalSubService(month);
			culture = mAPIBoardService.cultureSubService(para);
		
		} else {
			oasis = mAPIBoardService.oasisMainService();
			treasure = mAPIBoardService.treasureMainService();
			facility = mAPIBoardService.facilityMainService();
			festival = mAPIBoardService.festivalMainService();
			culture = mAPIBoardService.cultureMainService();
		}
		
		mav.addObject("oasis", oasis);
		mav.addObject("treasure", treasure);
		mav.addObject("facility", facility);
		mav.addObject("festival", festival);
		mav.addObject("culture", culture);
		
		return mav;
	}
	
	@RequestMapping(value="/oasis/list")
	public ModelAndView oasisboardList(Criteria cri) throws Exception{
		ModelAndView mav = new ModelAndView("/main/oasis");
		
		PageMarker pageMarker = new PageMarker();
		pageMarker.setCri(cri);
		pageMarker.setTotalCount(mAPIBoardService.oasisCountService());
		
		List<Map<String, Object>> list = mAPIBoardService.oasisListService(cri);
		mav.addObject("list", list);
		mav.addObject("pageMarker", pageMarker);
		
		return mav;
	}
	
	@RequestMapping(value="/oasis/detail/{id}")
	private String oasisboardDetail(@PathVariable int id, Model model) throws Exception{
		model.addAttribute("detail", mAPIBoardService.oasisDetailService(id));
		return "/detail/oasis";
	}
	
	@RequestMapping(value="/culture/list")
	private ModelAndView cultureboardList(Criteria cri) throws Exception{
		ModelAndView mav = new ModelAndView("/main/culture");	
		
		PageMarker pageMarker = new PageMarker();
		pageMarker.setCri(cri);
		pageMarker.setTotalCount(mAPIBoardService.cultureCountService());
		
		List<Map<String, Object>> list = mAPIBoardService.cultureListService(cri);
		mav.addObject("list", list);
		mav.addObject("pageMarker", pageMarker);
		
		return mav;
	}
	
	@RequestMapping(value="/culture/detail/{idx}")
	private String cultureboardDetail(@PathVariable int idx, Model model) throws Exception{
		model.addAttribute("detail", mAPIBoardService.cultureDetailService(idx));
		return "/detail/culture";
	}
	

	@RequestMapping(value="/facility/list")
	private ModelAndView facilityboardList(Criteria cri) throws Exception{
		ModelAndView mav = new ModelAndView("/main/facility");	
		
		PageMarker pageMarker = new PageMarker();
		pageMarker.setCri(cri);
		pageMarker.setTotalCount(mAPIBoardService.facilityCountService());
		
		List<Map<String, Object>> list = mAPIBoardService.facilityListService(cri);
		mav.addObject("list", list);
		mav.addObject("pageMarker", pageMarker);
		
		return mav;
	}
	
	@RequestMapping(value="/facility/detail/{idx}")
	private String facilityboardDetail(@PathVariable int idx, Model model) throws Exception{
		model.addAttribute("detail", mAPIBoardService.facilityDetailService(idx));
		return "/detail/facility";
	}
	

	@RequestMapping(value="/festival/list")
	private ModelAndView festivalboardList(Criteria cri) throws Exception{
		ModelAndView mav = new ModelAndView("/main/festival");	
		
		PageMarker pageMarker = new PageMarker();
		pageMarker.setCri(cri);
		pageMarker.setTotalCount(mAPIBoardService.festivalCountService());
		
		List<Map<String, Object>> list = mAPIBoardService.festivalListService(cri);
		mav.addObject("list", list);
		mav.addObject("pageMarker", pageMarker);
		
		return mav;
	}
	
	@RequestMapping(value="/festival/detail/{idx}")
	private String festivalboardDetail(@PathVariable int idx, Model model) throws Exception{
		model.addAttribute("detail", mAPIBoardService.festivalDetailService(idx));
		return "/detail/festival";
	}
	

	@RequestMapping(value="/treasure/list")
	private ModelAndView treasureboardList(Criteria cri) throws Exception{
		ModelAndView mav = new ModelAndView("/main/treasure");	
		
		PageMarker pageMarker = new PageMarker();
		pageMarker.setCri(cri);
		pageMarker.setTotalCount(mAPIBoardService.treasureCountService());
		
		List<Map<String, Object>> list = mAPIBoardService.treasureListService(cri);
		mav.addObject("list", list);
		mav.addObject("pageMarker", pageMarker);
		
		return mav;
	}
	
	@RequestMapping(value="/treasure/detail/{idx}")
	private String treasureboardDetail(@PathVariable int idx, Model model) throws Exception{
		model.addAttribute("detail", mAPIBoardService.treasureDetailService(idx));
		return "/detail/treasure";
	}
}
