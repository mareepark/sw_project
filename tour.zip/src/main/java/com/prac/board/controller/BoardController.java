package com.prac.board.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prac.board.domain.BoardVO;
import com.prac.board.service.BoardService;

@Controller
public class BoardController {

	@Resource(name = "com.prac.board.service.BoardService")
	BoardService mBoardService;
	
	@RequestMapping("/board/list")
	private String boardList(Model model) throws Exception{
		model.addAttribute("list", mBoardService.boardListService());
		return "/board/list";
	}
	
	@RequestMapping("/board/detail/{seq}")
	private String boardDetail(@PathVariable int seq, Model model) throws Exception{
		model.addAttribute("detail", mBoardService.boardDetailService(seq));
		return "/board/detail";
	}
	
	@RequestMapping("/board/insert")
	private String boardInsertForm() {
		return "/board/insert";
	}
	
	@RequestMapping("/board/insertProc")
	private String boardInsertProc(HttpServletRequest request) throws Exception{
		BoardVO board = new BoardVO();
		
		board.setTitle(request.getParameter("title"));
		board.setContent(request.getParameter("content"));
		board.setWriter(request.getParameter("writer"));
		board.setSeq(mBoardService.boardCountService());
		
		mBoardService.boardInsertService(board);
		return "redirect:/board/list";
	}
	
	@RequestMapping("/board/update/{seq}")
	private String boardUpdateForm(@PathVariable int seq, Model model) throws Exception{
		model.addAttribute("detail", mBoardService.boardDetailService(seq));
		return "/board/update";
	}
	
	@RequestMapping("/board/updateProc")
	private String boardUpdateProc(HttpServletRequest request) throws Exception{
		BoardVO board = new BoardVO();
		
		board.setTitle(request.getParameter("title"));
		board.setContent(request.getParameter("content"));
		board.setWriter(request.getParameter("writer"));
		board.setSeq(Integer.parseInt(request.getParameter("seq")));
		
		mBoardService.boardInsertService(board);
		return "redirect:/board/detail/" + request.getParameter("seq");
	}
	
	@RequestMapping("/board/delete/{seq}")
	private String boardDelete(@PathVariable int seq) throws Exception{
		mBoardService.boardDeleteService(seq);
		return "redirect:/board/list";
	}
}
