package com.prac.board.parse;

import java.io.BufferedInputStream;
import java.net.URL;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.prac.board.domain.CultureVO;
import com.prac.board.domain.FacilityVO;
import com.prac.board.domain.FestivalVO;
import com.prac.board.domain.OasisVO;
import com.prac.board.domain.TreasureVO;



public class APIParse {
	
	private ArrayList<OasisVO> soas = null;
	private OasisVO oasis = null;
	private ArrayList<TreasureVO> stre = null;
	private TreasureVO treasure = null;
	private ArrayList<FestivalVO> sfes = null;
	private FestivalVO festival = null;
	private ArrayList<FacilityVO> sfac = null;
	private FacilityVO facility = null;
	private ArrayList<CultureVO> scul = null;
	private ArrayList<ArrayList<CultureVO>> sscul = null;
	private CultureVO culture = null;
	
	
	public ArrayList<OasisVO> OaAPIParser() throws Exception{
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(readUrl("oasis"));
		JSONArray jsonArray = (JSONArray) jsonObject.get("features");

		soas = new ArrayList<OasisVO>();
		
		for(int i=0 ; i < jsonArray.size() ; i++) {
			
			oasis = new OasisVO();
			
			JSONObject ro = (JSONObject) jsonArray.get(i);
			JSONObject row = (JSONObject) ro.get("properties");
			
			oasis.setOasisid(0);
			oasis.setOasisid(Integer.parseInt(Long.toString((long) row.get("objectid"))));
			oasis.setOasisCODE((String)row.get("sgg"));
			oasis.setOasisFD((String)row.get("spc_nm"));
			oasis.setOasisCT((String)row.get("program"));
			oasis.setOasisEXH((String)row.get("genre"));
			oasis.setOasisADD((String)row.get("adres"));
			oasis.setOasisNUM((String)row.get("spc_telno"));
			
			//features [] properties {} Array = [] object = {}
			soas.add(oasis);
		}
		
		oasis.setOasisid(0);
		soas.add(oasis);
		
		return soas;
	}
	
	public ArrayList<TreasureVO> TrAPIParser() throws Exception{
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(readUrl("treasure"));
		
		stre = new ArrayList<TreasureVO>();
		
		for(int i=1 ; i < jsonArray.size() ; i++) {
			
			treasure = new TreasureVO();
			
			JSONObject row = (JSONObject) jsonArray.get(i);
			
			treasure.setIdx(0);
			treasure.setIdx(Integer.parseInt((String)row.get("idx")));
			treasure.setTitle((String)row.get("title"));
			treasure.setRegion((String)row.get("region"));
			treasure.setGubun((String)row.get("gubun"));
			treasure.setNumber((String)row.get("number"));
			treasure.setDate((String)row.get("date"));
			treasure.setQty((String)row.get("qty"));
			treasure.setAdmin((String)row.get("admin"));
			treasure.setLocation((String)row.get("location"));
			treasure.setPoster((String)row.get("poster"));
			treasure.setDescription((String)row.get("description"));
			
			//features [] properties {} Array = [] object = {}
			stre.add(treasure);
		}
		
		treasure.setIdx(0);
		stre.add(treasure);
		
		return stre;
	}
	
	public ArrayList<FestivalVO> FsAPIParser() throws Exception{
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(readUrl("festival"));
		
		sfes = new ArrayList<FestivalVO>();
		// idx title gubun organ syear period tel description
		for(int i=1 ; i < jsonArray.size() ; i++) {
			
			festival = new FestivalVO();
			
			JSONObject row = (JSONObject) jsonArray.get(i);
			
			festival.setIdx(0);
			festival.setIdx(Integer.parseInt((String)row.get("idx")));
			festival.setTitle((String)row.get("title"));
			
			switch((String)row.get("gubun")) {
			case "g1":
				festival.setGubun("문화예술");
				break;
			case "g2":
				festival.setGubun("관광특산");
				break;
			case "g3":
				festival.setGubun("전통민속");
				break;
			case "g4":
				festival.setGubun("동축제");
				break;
			default :
				festival.setGubun("기타");
				break;
			}

			festival.setOrgan((String)row.get("organ"));
			festival.setSyear((String)row.get("syear"));
			festival.setPeriod((String)row.get("period"));
			festival.setTel((String)row.get("tel"));
			festival.setDescription((String)row.get("description"));
			
			//features [] properties {} Array = [] object = {}
			sfes.add(festival);
		}
		
		festival.setIdx(0);
		sfes.add(festival);
		
		return sfes;
	}
	
	public ArrayList<FacilityVO> FaAPIParser() throws Exception{
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(readUrl("facility"));
		
		sfac = new ArrayList<FacilityVO>();
		// idx title gubun cat adress tel homepage poster description
		for(int i=1 ; i < jsonArray.size() ; i++) {
			
			facility = new FacilityVO();
			
			JSONObject row = (JSONObject) jsonArray.get(i);
			
			facility.setIdx(0);
			facility.setIdx(Integer.parseInt((String)row.get("idx")));
			facility.setTitle((String)row.get("title"));
			facility.setGubun((String)row.get("gubun"));
			facility.setCat((String)row.get("cat"));
			facility.setAddress((String)row.get("address"));
			facility.setTel((String)row.get("tel"));
			facility.setHomepage((String)row.get("homepage"));
			facility.setPoster((String)row.get("poster"));
			facility.setDescription((String)row.get("description"));
			
			//features [] properties {} Array = [] object = {}
			sfac.add(facility);
		}
		
		facility.setIdx(0);
		sfac.add(facility);
		
		return sfac;
	}
	
	public ArrayList<ArrayList<CultureVO>> CuAPIParser() throws Exception{
		int page = readPage();
		JSONParser jsonParser = new JSONParser();
		sscul = new ArrayList<ArrayList<CultureVO>>();
		String[] culSave = new String[page];
		culSave = readCultureUrl();
		
		for(int idx=0 ; idx<page ; idx++) {
			JSONArray jsonArray = (JSONArray) jsonParser.parse(culSave[idx]);
		
			scul = new ArrayList<CultureVO>();
			// idx title category sdate edate place place_gugun
			// management fee_case fee tel homepage poster description
			for(int i=1 ; i < jsonArray.size() ; i++) {
			
				culture = new CultureVO();
			
				JSONObject row = (JSONObject) jsonArray.get(i);
			
				culture.setIdx(0);
				culture.setIdx(Integer.parseInt((String)row.get("idx")));
				culture.setTitle((String)row.get("title"));
				culture.setCategory((String)row.get("category"));
				culture.setSdate((String)row.get("sdate"));
				culture.setEdate((String)row.get("edate"));
				culture.setPlace((String)row.get("place"));
				culture.setPlace_gugun((String)row.get("place_gugun"));
				culture.setManagement((String)row.get("management"));
				culture.setFee_case((String)row.get("fee_case"));
				culture.setFee((String)row.get("fee"));
				culture.setTel((String)row.get("tel"));
				culture.setHomepage((String)row.get("homepage"));
				culture.setPoster((String)row.get("poster"));
				culture.setDescription((String)row.get("description"));
				
				//	features [] properties {} Array = [] object = {}
				scul.add(culture);
			}
		
			culture.setIdx(0);
			scul.add(culture);
			sscul.add(scul);
			}
		return sscul;
	}
	
	private static String readUrl(String bungi) throws Exception{
		BufferedInputStream reader = null;
		
		switch(bungi) {
			case "oasis":
				bungi = "https://icloudgis.incheon.go.kr"
						+ "/server/rest/services/Hosted/CultureOasis"
						+ "/FeatureServer/0/query?outFields=*&where=1%3D1&f=geojson";
				break;
			case "treasure":
				bungi = "http://iq.ifac.or.kr/openAPI/real/search.php?" + 
						"svID=treasure" + 
						"&apiKey=mwqa4bkh9L17EArfVJvKCdF3ylUzRt" + 
						"&resultType=json" +
						"&pSize=500";
				break;
			case "festival":
				bungi = "http://iq.ifac.or.kr/openAPI/real/search.php?" + 
						"svID=festival" + 
						"&apiKey=cMx7d3CQDrwU8X5NHYJLkB92qpsESF" + 
						"&resultType=json" +
						"&pSize=200";
				break;
			case "facility":
				bungi = "http://iq.ifac.or.kr/openAPI/real/search.php?" + 
						"svID=facility" + 
						"&apiKey=9zjJL6lpqBvF5DZbys2uhfw8xSEaNP" + 
						"&resultType=json" +
						"&pSize=500";
				break;
			default :
				System.out.println("Parse Fail");
				break;
		}
		
		try {
			URL url = new URL(bungi);
			
			reader = new BufferedInputStream(url.openStream());
			StringBuffer buffer = new StringBuffer();
			int i = 0;
			byte[] b = new byte[4096];
			while((i = reader.read(b)) != -1) {
				buffer.append(new String(b, 0, i));
			}
			return buffer.toString().replaceAll("\\uFEFF", "");
		} finally {
			if(reader != null) reader.close();
		}
	}
	
	private static String[] readCultureUrl() throws Exception{
		int page = readPage();
		BufferedInputStream reader = null;
		String bungi = null;
		String[] culSave = new String[page];
		
		for(int idx=1 ; idx < page + 1 ; idx++) {
		
			bungi = "http://iq.ifac.or.kr/openAPI/real/search.php?" + 
					"svID=culture" + 
					"&apiKey=b4jrzClPeN7n1AZdwk5pVY3SG9hayt" + 
					"&resultType=json" +
					"&pSize=999" + 
					"&cPage=" + idx;
			
			try {
				URL url = new URL(bungi);
			
				reader = new BufferedInputStream(url.openStream());
				StringBuffer buffer = new StringBuffer();
				int i = 0;
				byte[] b = new byte[4096];
				while((i = reader.read(b)) != -1) {
					buffer.append(new String(b, 0, i));
				}
				culSave[idx - 1] = buffer.toString().replaceAll("\\uFEFF", "");
			} finally {
				if(reader != null) reader.close();
			}
		}
		return culSave;
	}

	private static int readPage() throws Exception{
		BufferedInputStream reader = null;
		
		String add = "http://iq.ifac.or.kr/openAPI/real/search.php?" + 
					 "svID=culture" + 
					 "&apiKey=b4jrzClPeN7n1AZdwk5pVY3SG9hayt" + 
					 "&resultType=json";
		
		try {
			URL url = new URL(add);
			
			reader = new BufferedInputStream(url.openStream());
			StringBuffer buffer = new StringBuffer();
			int i = 0;
			byte[] b = new byte[4096];
			while((i = reader.read(b)) != -1) {
				buffer.append(new String(b, 0, i));
			}
			add = buffer.toString().replaceAll("\\uFEFF", "");
		} finally {
			if(reader != null) reader.close();
		}
		
		int pageSave;
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(add);
		JSONObject row = (JSONObject) jsonArray.get(0);
		
		pageSave = Integer.parseInt((String)row.get("totalCnt"));
		
		return (pageSave/999 + 1);
	}
}





/*
public String getOasisJSON() {
	String sURL = "https://icloudgis.incheon.go.kr"
			+ "/server/rest/services/Hosted/CultureOasis"
			+ "/FeatureServer/0/query?outFields=*&where=1%3D1&f=geojson";
	String line = "";
	String result = "";
	
	try {
		URL url = new URL(sURL);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-Type", "application/json");
		BufferedReader bf = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
		
		while((line=bf.readLine()) != null) {
			result = result.concat(line);
		}
		
		bf.close();
		conn.disconnect();
		
		return result;
	} catch (Exception e) {
		System.out.println("Exception : " + e.getMessage());
		return result;
	}
}
}
*/
/*
public String[] getOasis(String result, int idx) {
		//String strOasis[] = new String[7];
		String tag[] = {"objectid", "sgg", "spc_nm", "program", "genre", "adres", "spc_telno"};
		
		com.google.gson.JsonParser parser = new com.google.gson.JsonParser();
		JsonElement jsonElement = parser.parse(result).getAsJsonObject();
		String name = jsonElement.getAsJsonObject().get("properties").getAsString();
		System.out.println(name);
		
		return tag;
		/*
		JsonObject data = jsonElement.getAsJsonObject();
		data = data.getAsJsonObject("features");
				
		strOasis[0] = "0";
		
		try {
			for(int inx = 0 ; inx < tag.length ; inx++) {
				strOasis[inx] = data.get("properties").getAsJsonObject().get(tag[inx]).getAsString();
				System.out.println(strOasis[inx]);
			}
		
		} catch(Exception e) {
			e.printStackTrace();
		}
		return strOasis;
		
		/*
		oasis.setAdd(data.get(tag[3]).toString());
		oasis.setCode(data.get(tag[1]).toString());
		oasis.setCt(data.get(tag[6]).toString());
		oasis.setExh(data.get(tag[5]).toString());
		oasis.setFd(data.get(tag[2]).toString());
		oasis.setId(Integer.parseInt(data.get(tag[0]).toString()));
		oasis.setNum(Integer.parseInt(data.get(tag[4]).toString().replaceAll("-", "")));
			*/
		
		//com.google.gson.JsonParser parser = new com.google.gson.JsonParser();
		//JsonObject jsonArray = (JsonObject) parser.parse(result);
		//JsonArray jsonArray = (JsonArray) parser.parse(result);
		
		//JsonArray jsonArray = new JsonArray();
		//jsonArray = (JsonArray) parser.parse(result);
		//System.out.println(jsonArray);
		
		//JsonElement data = (JsonElement) jsonArray.getAsJsonObject().get
		//JsonObject object = (JsonObject) jsonArray.get("id");
		
		//JsonArray jsonA = data.getAsJsonArray("properties");
		//JsonObject data = object.getAsJsonObject("properties");
		//JsonObject data2 = jsonA.get(idx).getAsJsonObject();
		//System.out.println(object);
		
		/*
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonBase = (JSONObject) jsonParser.parse(result);
		JSONObject jsonProp = (JSONObject) jsonBase.get("properties");
		JSONArray answer = (JSONArray) jsonProp.get("properties");
		
		JSONObject obj;
		String tag[] = {"objectid", "sgg", "spc_nm", "adres", "spc_telno",
				"prj_nm", "genre", "program"};
		int legth = jsonProp.size();
		OasisVO[] oasis = new OasisVO[legth];
		
		
		for(int i = 0 ; i < legth ; i++) {
			obj = (JSONObject) answer.get(i);
			String nam = (String) jsonProp.get("name");
			
			oasis[i].setId(Integer.parseInt(.get(tag[0]).toString()));
			oasis[i].setNum(Integer.parseInt(obj.get(tag[4]).toString().replaceAll("-", "")));
			oasis[i].setFd((obj.get(tag[2])).toString());
			oasis[i].setAdd((obj.get(tag[3])).toString());
			oasis[i].setCode((obj.get(tag[1])).toString());
			oasis[i].setCt((obj.get(tag[7])).toString());
			oasis[i].setExh((obj.get(tag[6])).toString());
			
			*/
			/*
			switch(category) {
			case "objectid" : 
				oasis.id = Integer.parseInt(obj.get("objectid").toString());
				break;
			case "spc_telno" : 
				oasis.num = Integer.parseInt(obj.get("spc_telno").toString().replaceAll("-", ""));
				break;
			case "sgg" : 
				oasis.code = (obj.get("sgg")).toString();
				break;
			case "spc_nm" : 
				oasis.fd = (obj.get("spc_nm")).toString();
				break;
			case "program" : 
				oasis.ct = (obj.get("program")).toString();
				break;
			case "genre" : 
				oasis.exh = (obj.get("genre")).toString();
				break;
			case "adres" : 
				oasis.add = (obj.get("adres")).toString();
				break;
			}
			*/
		/*
			if(legth > idx)
				return oasis[idx];
			else
				return fail;
		}
	} catch(Exception e) {
		System.out.println("Exception : " + e.getMessage());
	}
	return fail;
	*/
//}

// objectid spc-telno sgg spc-nm program genre adres
