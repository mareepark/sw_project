package com.prac.board.service;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.prac.board.domain.CultureVO;
import com.prac.board.domain.FacilityVO;
import com.prac.board.domain.FestivalVO;
import com.prac.board.domain.OasisVO;
import com.prac.board.domain.TreasureVO;
import com.prac.board.mapper.APIMapper;


@Service("com.prac.board.service.APIService")
public class APIService {
	@Resource(name = "com.prac.board.mapper.APIMapper")
	APIMapper mAPIMapper;
	
	public int oasisInsertService(OasisVO oasis) throws Exception{
		return mAPIMapper.oasisInsert(oasis);
	}

	public int treasureInsertService(TreasureVO treasureVO) throws Exception{
		return mAPIMapper.treasureInsert(treasureVO);
	}
	
	public int festivalInsertService(FestivalVO festivalVO) throws Exception{
		return mAPIMapper.festivalInsert(festivalVO);
	}
	
	public int facilityInsertService(FacilityVO facilityVO) throws Exception{
		return mAPIMapper.facilityInsert(facilityVO);
	}

	public int cultureInsertService(CultureVO cultureVO) throws Exception{
		return mAPIMapper.cultureInsert(cultureVO);
	}
	
	public int oasisDeleteService() throws Exception{
		return mAPIMapper.oasisDelete();
	}
	
	public int treasureDeleteService() throws Exception{
		return mAPIMapper.treasureDelete();
	}
	
	public int facilityDeleteService() throws Exception{
		return mAPIMapper.facilityDelete();
	}
	
	public int festivalDeleteService() throws Exception{
		return mAPIMapper.festivalDelete();
	}
	
	public int cultureDeleteService() throws Exception{
		return mAPIMapper.cultureDelete();
	}
	
	public int oasisFindService(int idx) throws Exception{
		return mAPIMapper.oasisFind(idx);
	}
	
	public int treasureFindService(int idx) throws Exception{
		return mAPIMapper.treasureFind(idx);
	}
	
	public int festivalFindService(int idx) throws Exception{
		return mAPIMapper.festivalFind(idx);
	}
	
	public int facilityFindService(int idx) throws Exception{
		return mAPIMapper.facilityFind(idx);
	}
	
	public int cultureFindService(int idx) throws Exception{
		return mAPIMapper.cultureFind(idx);
	}
}