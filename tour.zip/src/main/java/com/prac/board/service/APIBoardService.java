package com.prac.board.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.prac.board.domain.CultureVO;
import com.prac.board.domain.FacilityVO;
import com.prac.board.domain.FestivalVO;
import com.prac.board.domain.OasisVO;
import com.prac.board.domain.ParameterVO;
import com.prac.board.domain.TreasureVO;
import com.prac.board.mapper.APIBoardMapper;
import com.prac.board.parse.Criteria;

@Service("com.prac.board.service.APIBoardService")
public class APIBoardService {
	@Resource(name="com.prac.board.mapper.APIBoardMapper")
	APIBoardMapper mAPIBoardMapper;

	public List<Map<String, Object>> oasisListService(Criteria cri) throws Exception{
		return mAPIBoardMapper.OasisList(cri);
	}
	public OasisVO oasisDetailService(int id) throws Exception{
		return mAPIBoardMapper.OasisDetail(id);
	}

	public List<Map<String, Object>> cultureListService(Criteria cri) throws Exception{
		return mAPIBoardMapper.CultureList(cri);
	}
	public CultureVO cultureDetailService(int idx) throws Exception{
		return mAPIBoardMapper.CultureDetail(idx);
	}

	public List<Map<String, Object>> facilityListService(Criteria cri) throws Exception{
		return mAPIBoardMapper.FacilityList(cri);
	}
	public FacilityVO facilityDetailService(int idx) throws Exception{
		return mAPIBoardMapper.FacilityDetail(idx);
	}
	
	public List<Map<String, Object>> festivalListService(Criteria cri) throws Exception{
		return mAPIBoardMapper.FestivalList(cri);
	}
	public FestivalVO festivalDetailService(int idx) throws Exception{
		return mAPIBoardMapper.FestivalDetail(idx);
	}
	
	public List<Map<String, Object>> treasureListService(Criteria cri) throws Exception{
		return mAPIBoardMapper.TreasureList(cri);
	}
	public TreasureVO treasureDetailService(int idx) throws Exception{
		return mAPIBoardMapper.TreasureDetail(idx);
	}
	
	
	public int oasisCountService() throws Exception{
		return mAPIBoardMapper.OasisCount();
	}
	
	public int cultureCountService() throws Exception{
		return mAPIBoardMapper.CultureCount();
	}
	
	public int facilityCountService() throws Exception{
		return mAPIBoardMapper.FacilityCount();
	}
	
	public int festivalCountService() throws Exception{
		return mAPIBoardMapper.FestivalCount();
	}
	
	public int treasureCountService() throws Exception{
		return mAPIBoardMapper.TreasureCount();
	}
	
	public List<Map<String, Object>> oasisMainService() throws Exception{
		return mAPIBoardMapper.OasisMain();
	}
	
	public List<Map<String, Object>> treasureMainService() throws Exception{
		return mAPIBoardMapper.TreasureMain();
	}
	
	public List<Map<String, Object>> facilityMainService() throws Exception{
		return mAPIBoardMapper.FacilityMain();
	}
	
	public List<Map<String, Object>> festivalMainService() throws Exception{
		return mAPIBoardMapper.FestivalMain();
	}
	
	public List<Map<String, Object>> cultureMainService() throws Exception{
		return mAPIBoardMapper.CultureMain();
	}
	
	public List<Map<String, Object>> oasisSubService(String locat) throws Exception{
		return mAPIBoardMapper.OasisSub(locat);
	}
	
	public List<Map<String, Object>> treasureSubService(String locat) throws Exception{
		return mAPIBoardMapper.TreasureSub(locat);
	}
	
	public List<Map<String, Object>> facilitySubService(String locat) throws Exception{
		return mAPIBoardMapper.FacilitySub(locat);
	}
	
	public List<Map<String, Object>> festivalSubService(int time) throws Exception{
		return mAPIBoardMapper.FestivalSub(time);
	}
	
	public List<Map<String, Object>> cultureSubService(ParameterVO para) throws Exception{
		return mAPIBoardMapper.CultureSub(para);
	}
}