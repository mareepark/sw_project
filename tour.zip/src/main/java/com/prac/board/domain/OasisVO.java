package com.prac.board.domain;

import lombok.*;

@Getter
@Setter
@ToString
public class OasisVO {
	public int oasisid; //objectid v
	public String oasisCODE; // sgg 중구 v
	public String oasisFD; // spc_nm v
	public String oasisCT; // program
	public String oasisEXH; // prj_nm v
	public String oasisADD; // adres
	public String oasisNUM; // spc_telno	
}
