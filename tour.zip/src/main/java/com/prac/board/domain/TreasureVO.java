package com.prac.board.domain;

import lombok.*;

@Getter
@Setter
@ToString
public class TreasureVO {
	public int idx;
	public String title;
	public String region;
	public String gubun;
	public String number;
	public String date;
	public String qty;
	public String admin;
	public String location;
	public String poster;
	public String description;
}
