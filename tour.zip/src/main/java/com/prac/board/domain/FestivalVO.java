package com.prac.board.domain;

import lombok.*;

@Getter
@Setter
@ToString
public class FestivalVO {
	public int idx;//
	public String title;//
	public String gubun;//
	public String organ;
	public String syear;
	public String period;//
	public String tel;
	public String description;
}
