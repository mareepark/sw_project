package com.prac.board.domain;

import lombok.Data;

@Data
public class ParameterVO {
	public int time;
	public String location;
}
