package com.prac.board.domain;

import lombok.*;

@Getter
@Setter
@ToString
public class CultureVO {
	public int idx;//
	public String title;//
	public String category;//
	public String sdate;
	public String edate;
	public String place;//
	public String place_gugun;
	public String management;
	public String fee_case;//
	public String fee;
	public String tel;
	public String homepage;
	public String poster;
	public String description;
}
