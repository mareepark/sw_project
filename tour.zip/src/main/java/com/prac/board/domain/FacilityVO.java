package com.prac.board.domain;

import lombok.*;

@Getter
@Setter
@ToString
public class FacilityVO {
	public int idx;//
	public String title;//
	public String gubun;//
	public String cat;//
	public String address;
	public String tel;
	public String homepage;
	public String poster;
	public String description;
}
