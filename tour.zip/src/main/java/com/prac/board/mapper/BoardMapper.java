package com.prac.board.mapper;

import org.springframework.stereotype.Repository;
import java.util.List;
import com.prac.board.domain.BoardVO;

@Repository("com.prac.board.mapper.BoardMapper")
public interface BoardMapper {
	// 글 개수
	public int boardCount() throws Exception;
	// 글 목록
	public List<BoardVO> boardList() throws Exception;
	// 글 상세
	public BoardVO boardDetail(int seq) throws Exception;
	// 글 작성
	public int boardInsert(BoardVO board) throws Exception;
	// 글 수정
	public int boardUpdate(BoardVO board) throws Exception;
	// 글 삭제
	public int boardDelete(int seq) throws Exception;
}
