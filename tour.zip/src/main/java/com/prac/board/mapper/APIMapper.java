package com.prac.board.mapper;

import org.springframework.stereotype.Repository;

import com.prac.board.domain.CultureVO;
import com.prac.board.domain.FacilityVO;
import com.prac.board.domain.FestivalVO;
import com.prac.board.domain.OasisVO;
import com.prac.board.domain.TreasureVO;

@Repository("com.prac.board.mapper.APIMapper")
public interface APIMapper {
	
	public int oasisInsert(OasisVO oasisVO) throws Exception;
	
	public int treasureInsert(TreasureVO treasureVO) throws Exception;
		
	public int festivalInsert(FestivalVO festivalVO) throws Exception;
	
	public int facilityInsert(FacilityVO facilityVO) throws Exception;
	
	public int cultureInsert(CultureVO cultureVO) throws Exception;
	
	public int oasisDelete() throws Exception;
	
	public int treasureDelete() throws Exception;
	
	public int facilityDelete() throws Exception;
	
	public int festivalDelete() throws Exception;
	
	public int cultureDelete() throws Exception;
	
	public int oasisFind(int idx) throws Exception;
	
	public int treasureFind(int idx) throws Exception;
	
	public int festivalFind(int idx) throws Exception;
	
	public int facilityFind(int idx) throws Exception;
	
	public int cultureFind(int idx) throws Exception;
}
