package com.prac.board.mapper;

import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Map;

import com.prac.board.domain.CultureVO;
import com.prac.board.domain.FacilityVO;
import com.prac.board.domain.FestivalVO;
import com.prac.board.domain.OasisVO;
import com.prac.board.domain.ParameterVO;
import com.prac.board.domain.TreasureVO;
import com.prac.board.parse.Criteria;

@Repository("com.prac.board.mapper.APIBoardMapper")
public interface APIBoardMapper {
	// 글 목록
	public List<Map<String, Object>> OasisList(Criteria cri) throws Exception;
	// 글 상세
	public OasisVO OasisDetail(int id) throws Exception;
	
	// 글 목록
	public List<Map<String, Object>> CultureList(Criteria cri) throws Exception;
	// 글 상세
	public CultureVO CultureDetail(int idx) throws Exception;

	// 글 목록
	public List<Map<String, Object>> FacilityList(Criteria cri) throws Exception;
	// 글 상세
	public FacilityVO FacilityDetail(int idx) throws Exception;
	
	// 글 목록
	public List<Map<String, Object>> FestivalList(Criteria cri) throws Exception;
	// 글 상세
	public FestivalVO FestivalDetail(int idx) throws Exception;
	
	// 글 목록
	public List<Map<String, Object>> TreasureList(Criteria cri) throws Exception;
	// 글 상세
	public TreasureVO TreasureDetail(int idx) throws Exception;
	
	public int OasisCount() throws Exception;
	
	public int CultureCount() throws Exception;
	
	public int FacilityCount() throws Exception;
	
	public int FestivalCount() throws Exception;
	
	public int TreasureCount() throws Exception;
	
	public List<Map<String, Object>> OasisMain() throws Exception;
	
	public List<Map<String, Object>> TreasureMain() throws Exception;
	
	public List<Map<String, Object>> FacilityMain() throws Exception;
	
	public List<Map<String, Object>> FestivalMain() throws Exception;
	
	public List<Map<String, Object>> CultureMain() throws Exception;
	
	public List<Map<String, Object>> OasisSub(String locat) throws Exception;
	
	public List<Map<String, Object>> TreasureSub(String locat) throws Exception;
	
	public List<Map<String, Object>> FacilitySub(String locat) throws Exception;
	
	public List<Map<String, Object>> FestivalSub(int time) throws Exception;
	
	public List<Map<String, Object>> CultureSub(ParameterVO para) throws Exception;
}
